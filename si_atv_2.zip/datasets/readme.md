# env

Contém arquivos de configuração do ambiente (environment).

# vict

Contém os datasets com sinais vitais das vítimas.
O nome da pasta indica o número de vítimas do dataset.
