# Atributos dos datasets

[Atributos](https://github.com/tacla/VictSim3/blob/94498189fd6687b54784c82324a30aa69b6dd665/data_creation/atributos.md)
